## Introduction

Welcome to the Statistical App! This application allows you to import, clean, analyze, and visualize data using various statistical methods and graphical representations.

## Features

1. **Import Data**: Upload your data files in `.csv`, `.txt`, `.xlsx`, `.dta`, or `.sav` formats.
2. **Data Cleaning**: Handle missing data by removing rows or imputing values.
3. **Statistics**: Get a summary of your data, view missing data, and create cross tabulations or frequency tables.
4. **Visualize Graph**: Generate various types of plots, including line graphs, bar graphs, scatter plots, histograms, and box plots.
5. **Statistical Modeling**: Perform different statistical tests such as ANOVA, logistic regression, probit regression, and linear regression.
6. **Correlation Matrix**: Generate a correlation matrix to understand the relationships between variables.
7. **Report**: Generate and download a comprehensive report of your analysis.
8. **Help**: Access help and documentation for using the application.

## How to Use the App

### Import Data

1. Navigate to the **Import Data** tab.
2. Click the "Upload Data" button and select your data file.
3. After uploading, choose the columns for the X-axis, Y-axis, color grouping, and type of graph.
4. Click "Upload Data" to load your data into the application.
5. The data summary will be displayed on the right.

### Data Cleaning

1. Navigate to the **Data Cleaning** tab.
2. Select the action to take for missing data: remove rows, impute with mean, or impute with median.
3. Click "Clean Data" to apply the selected action.

### Statistics

1. Navigate to the **Statistics** tab.
2. View the summary of your data and the missing data details.
3. Select the type of table you want to generate (Cross tabulation or Frequency Table).
4. Choose the variables for the table and click "Submit".
5. The generated table and its interpretation will be displayed.

### Visualize Graph

1. Navigate to the **Visualize Graph** tab.
2. The plot will be generated based on the selected columns and type of graph from the **Import Data** tab.
3. Click "Download Plot" to save the plot as a PNG file.

### Statistical Modeling

1. Navigate to the **Statistical Modeling** tab.
2. Select the type of test you want to perform.
3. Choose the dependent and independent variables.
4. Click "Submit" to generate the results.
5. The results and their interpretation will be displayed.

### Correlation Matrix

1. Navigate to the **Correlation Matrix** tab.
2. The correlation matrix will be generated and displayed.
3. An interpretation of the correlation matrix will be provided.

### Generate Report

1. Navigate to the **Report** tab.
2. Click "Download Report" to generate and download the report as an HTML file.

## FAQ

**Q: What file formats are supported for data upload?**
  A: The app supports `.csv`, `.txt`, `.xlsx`, `.dta`, and `.sav` formats.

**Q: How can I handle missing data?**
  A: You can remove rows with missing data or impute missing values with the mean or median in the **Data Cleaning** tab.

**Q: How can I save the generated plots?**
  A: You can download the plots as PNG files by clicking the "Download Plot" button in the **Visualize Graph** tab.

**Q: How can I generate a report of my analysis?**
  A: Navigate to the **Report** tab and click "Download Report" to generate an HTML report.

## Contact

For further assistance, please contact Email: mginakaiza@gmail.com
                                       Phone: +255 672 225 284

Thank you for using the Statistical App!
  