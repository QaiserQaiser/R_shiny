# Load necessary libraries
library(shiny)
library(shinydashboard)
library(ggplot2)
library(DT)
library(plotly)
library(ggcorrplot)
library(rmarkdown)
library(markdown)
library(readxl)
library(haven)  # For reading .dta and .sav files

# Define UI
ui <- dashboardPage(
  dashboardHeader(title = "Statistical App"),
  dashboardSidebar(
    sidebarMenu(
      menuItem("Import Data", tabName = "import_data", icon = icon("upload")),
      menuItem("Data Cleaning", tabName = "data_cleaning", icon = icon("broom")),
      menuItem("Statistics", tabName = "statistics", icon = icon("chart-bar")),
      menuItem("Visualize Graph", tabName = "visualize_graph", icon = icon("image")),
      menuItem("Statistical Modelling", tabName = "stat_modeling", icon = icon("calculator")),
      menuItem("Correlation Matrix", tabName = "correlation_matrix", icon = icon("th")),
      menuItem("Report", tabName = "report", icon = icon("file-alt")),
      menuItem("Help", tabName = "help", icon = icon("question-circle"))
    )
  ),
  dashboardBody(
    tabItems(
      tabItem(tabName = "import_data",
              fluidRow(
                box(title = "Upload Data", status = "primary", solidHeader = TRUE, width = 4,
                    fileInput("file", "Upload Data", accept = c(".csv", ".txt", ".xlsx", ".dta", ".sav")),
                    selectInput("x_axis", "X-axis", choices = NULL),
                    selectInput("y_axis", "Y-axis", choices = NULL),
                    selectInput("color", "Group by (color)", choices = NULL),
                    selectInput("geom", "Type of graph", choices = c("Line graph" = "line", "Bar graph" = "bar", "Scatter plot" = "point", "Histogram" = "histogram", "Box plot" = "boxplot")),
                    actionButton("upload_btn", "Upload Data", icon = icon("upload"))
                ),
                box(title = "Data Summary", status = "primary", solidHeader = TRUE, width = 8,
                    DTOutput("head")
                )
              )
      ),
      tabItem(tabName = "data_cleaning",
              fluidRow(
                box(title = "Data Cleaning", status = "primary", solidHeader = TRUE, width = 12,
                    selectInput("missing_action", "Missing Data Action", choices = c("Remove rows", "Impute with mean", "Impute with median")),
                    actionButton("clean_data", "Clean Data")
                )
              )
      ),
      tabItem(tabName = "statistics",
              fluidRow(
                box(title = "Summary", status = "primary", solidHeader = TRUE, width = 4,
                    verbatimTextOutput("summary")
                ),
                box(title = "Missing Data", status = "primary", solidHeader = TRUE, width = 8,
                    verbatimTextOutput("missing")
                ),
                box(title = "Tables", status = "primary", solidHeader = TRUE, width = 12,
                    selectInput("tabletype", "Type of your Table", choices = c("Cross tabulation", "Frequency Table")),
                    selectInput("var1", "Choose a variable", choices = NULL),
                    selectInput("var2", "Choose a variable", choices = NULL),
                    verbatimTextOutput("cross_tabulation"),
                    verbatimTextOutput("frequency_table"),
                    actionButton("submit", "Submit")
                ),
                box(title = "Interpretation", status = "primary", solidHeader = TRUE, width = 12,
                    verbatimTextOutput("interpretation_summary")
                )
              )
      ),
      tabItem(tabName = "visualize_graph",
              fluidRow(
                box(title = "Plot", status = "primary", solidHeader = TRUE, width = 12,
                    plotlyOutput("plot", height = "400px"),
                    downloadButton("download_plot", "Download Plot")
                )
              )
      ),
      tabItem(tabName = "stat_modeling",
              fluidRow(
                box(title = "Modeling", status = "primary", solidHeader = TRUE, width = 4,
                    selectInput("test", "Type of Test", choices = c("Anova", "Simple logit", "Simple probit", "Simple Linear Regression")),
                    selectInput("variable1", "Input the Dependent var", choices = NULL),
                    selectInput("variable2", "Input the Independent var", choices = NULL),
                    actionButton("call", "Submit")
                ),
                box(title = "Results", status = "primary", solidHeader = TRUE, width = 8,
                    verbatimTextOutput("regression_table")
                ),
                box(title = "Interpretation", status = "primary", solidHeader = TRUE, width = 12,
                    verbatimTextOutput("interpretation_regression")
                )
              )
      ),
      tabItem(tabName = "correlation_matrix",
              fluidRow(
                box(title = "Correlation Matrix", status = "primary", solidHeader = TRUE, width = 12,
                    plotOutput("correlation_plot")
                ),
                box(title = "Interpretation", status = "primary", solidHeader = TRUE, width = 12,
                    verbatimTextOutput("interpretation_correlation")
                )
              )
      ),
      tabItem(tabName = "report",
              fluidRow(
                box(title = "Generate Report", status = "primary", solidHeader = TRUE, width = 12,
                    downloadButton("download_report", "Download Report")
                )
              )
      ),
      tabItem(tabName = "help",
              fluidRow(
                box(title = "Help and Documentation", status = "primary", solidHeader = TRUE, width = 12,
                    includeMarkdown("help.md")
                )
              )
      )
    )
  )
)

# Define server logic
server <- function(input, output, session) {
  data <- reactiveVal()
  
  observeEvent(input$file, {
    req(input$file)
    ext <- tools::file_ext(input$file$name)
    df <- switch(ext,
                 "csv" = read.csv(input$file$datapath),
                 "txt" = read.table(input$file$datapath, header = TRUE, sep = "\t"),
                 "xlsx" = read_excel(input$file$datapath),
                 "dta" = read_dta(input$file$datapath),
                 "sav" = read_sav(input$file$datapath),
                 stop("Unsupported file type")
    )
    data(df)
  })
  
  observe({
    df <- data()
    updateSelectInput(session, "x_axis", choices = names(df))
    updateSelectInput(session, "y_axis", choices = names(df))
    updateSelectInput(session, "color", choices = names(df))
    updateSelectInput(session, "var1", choices = names(df))
    updateSelectInput(session, "var2", choices = names(df))
    updateSelectInput(session, "variable1", choices = names(df))
    updateSelectInput(session, "variable2", choices = names(df))
  })
  
  output$head <- renderDT({
    head(data())
  })
  
  output$summary <- renderPrint({
    summary(data())
  })
  
  output$interpretation_summary <- renderPrint({
    summary_data <- summary(data())
    interpretation <- "Summary of data:\n\n"
    for (var in names(summary_data)) {
      if (is.numeric(summary_data[[var]])) {
        interpretation <- paste0(interpretation, var, ": The average (mean) is ", mean(data()[[var]], na.rm = TRUE), 
                                 ". The middle value (median) is ", median(data()[[var]], na.rm = TRUE), 
                                 ". The spread of the data (standard deviation) is ", sd(data()[[var]], na.rm = TRUE), ".\n")
      } else {
        interpretation <- paste0(interpretation, var, ": The most frequently occurring value is ", names(which.max(table(data()[[var]]))), ".\n")
      }
    }
    interpretation
  })
  
  output$missing <- renderPrint({
    colSums(is.na(data()))
  })
  
  observeEvent(input$clean_data, {
    df <- data()
    if (input$missing_action == "Remove rows") {
      df <- df[complete.cases(df), ]
    } else if (input$missing_action == "Impute with mean") {
      for (i in seq_along(df)) {
        if (is.numeric(df[[i]])) {
          df[[i]][is.na(df[[i]])] <- mean(df[[i]], na.rm = TRUE)
        }
      }
    } else if (input$missing_action == "Impute with median") {
      for (i in seq_along(df)) {
        if (is.numeric(df[[i]])) {
          df[[i]][is.na(df[[i]])] <- median(df[[i]], na.rm = TRUE)
        }
      }
    }
    data(df)
  })
  
  output$plot <- renderPlotly({
    req(input$x_axis, input$y_axis)
    df <- data()
    p <- ggplot(df, aes_string(x = input$x_axis, y = input$y_axis, color = input$color)) +
      {
        if (input$geom == "line") geom_line()
        else if (input$geom == "bar") geom_bar(stat = "identity")
        else if (input$geom == "point") geom_point()
        else if (input$geom == "histogram") geom_histogram(binwidth = 1)
        else if (input$geom == "boxplot") geom_boxplot()
      }
    ggplotly(p)
  })
  
  output$correlation_plot <- renderPlot({
    df <- data()
    corr <- cor(df, use = "complete.obs")
    ggcorrplot::ggcorrplot(corr, lab = TRUE)
  })
  
  output$interpretation_correlation <- renderPrint({
    df <- data()
    corr <- cor(df, use = "complete.obs")
    interpretation <- "Correlation matrix:\n\n"
    high_corr <- which(abs(corr) > 0.7 & abs(corr) < 1, arr.ind = TRUE)
    if (nrow(high_corr) == 0) {
      interpretation <- paste0(interpretation, "No strong correlations found (|correlation| > 0.7).")
    } else {
      for (i in seq_len(nrow(high_corr))) {
        interpretation <- paste0(interpretation, names(df)[high_corr[i, 1]], " and ", names(df)[high_corr[i, 2]], ": ",
                                 round(corr[high_corr[i, 1], high_corr[i, 2]], 2), " - This indicates a strong ",
                                 ifelse(corr[high_corr[i, 1], high_corr[i, 2]] > 0, "positive", "negative"),
                                 " correlation.\n")
      }
    }
    interpretation
  })
  
  observeEvent(input$submit, {
    df <- data()
    output$cross_tabulation <- renderPrint({
      if (input$tabletype == "Cross tabulation") {
        table(df[[input$var1]], df[[input$var2]])
      }
    })
    
    output$frequency_table <- renderPrint({
      if (input$tabletype == "Frequency Table") {
        table(df[[input$var1]])
      }
    })
  })
  
  observeEvent(input$call, {
    df <- data()
    formula <- as.formula(paste(input$variable1, "~", input$variable2))
    result <- switch(input$test,
                     "Anova" = summary(aov(formula, data = df)),
                     "Simple logit" = summary(glm(formula, data = df, family = binomial(link = "logit"))),
                     "Simple probit" = summary(glm(formula, data = df, family = binomial(link = "probit"))),
                     "Simple Linear Regression" = summary(lm(formula, data = df))
    )
    output$regression_table <- renderPrint({
      result
    })
    
    output$interpretation_regression <- renderPrint({
      interpretation <- "Regression results:\n\n"
      if (input$test == "Anova") {
        interpretation <- paste0(interpretation, "The F-statistic is ", result[[1]][[4]], ", with a p-value of ", result[[1]][[5]], ". ",
                                 "This indicates ", ifelse(result[[1]][[5]] < 0.05, "a significant", "no significant"), 
                                 " relationship between the variables.\n")
      } else if (input$test %in% c("Simple logit", "Simple probit", "Simple Linear Regression")) {
        interpretation <- paste0(interpretation, "The coefficients of the regression model are as follows:\n")
        for (i in seq_along(result$coefficients)) {
          interpretation <- paste0(interpretation, names(result$coefficients)[i], ": ", result$coefficients[i], 
                                   ifelse(i == 1, " (intercept)", ""), "\n")
        }
        interpretation <- paste0(interpretation, "The model's p-values and confidence intervals should be considered to understand the significance and reliability of these coefficients.\n")
      }
      interpretation
    })
  })
  
  output$download_plot <- downloadHandler(
    filename = function() {
      paste("plot-", Sys.Date(), ".png", sep = "")
    },
    content = function(file) {
      req(input$x_axis, input$y_axis)
      df <- data()
      p <- ggplot(df, aes_string(x = input$x_axis, y = input$y_axis, color = input$color)) +
        {
          if (input$geom == "line") geom_line()
          else if (input$geom == "bar") geom_bar(stat = "identity")
          else if (input$geom == "point") geom_point()
          else if (input$geom == "histogram") geom_histogram(binwidth = 1)
          else if (input$geom == "boxplot") geom_boxplot()
        }
      ggsave(file, plot = p)
    }
  )
  
  output$download_report <- downloadHandler(
    filename = function() {
      paste("report-", Sys.Date(), ".html", sep = "")
    },
    content = function(file) {
      rmarkdown::render("report.Rmd", output_file = file)
    }
  )
}

# Run the application 
shinyApp(ui = ui, server = server)
